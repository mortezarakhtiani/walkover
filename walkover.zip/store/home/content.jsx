'use client';

import {
  Deals,
  FeaturedProducts,
  Info,
  PopularSneakers,
  Search,
  SpecialOffers,
} from './components';

export function StoreClientContent() {
  return (
    <div className="grid grid-cols-1 gap-6">
      {/*<Search />*/}
      <FeaturedProducts />
      <SpecialOffers />
      <PopularSneakers />
      <Deals />
      <Info />
    </div>
  );
}
