'use client';

import Link from 'next/link';
import {MoveLeft, MoveRight} from 'lucide-react';
import {Button} from '@/store/components/ui/button';
import {Info} from './components/info';
import {Order} from './components/order';

export function ShippingInfoContent() {
    return (
        <div className="grid xl:grid-cols-3 gap-5 lg:gap-9 mb-5 lg:mb-10">
            <div className="lg:col-span-2 space-y-5">
                <div className="grid sm:grid-cols-2 gap-5">
                    <Info/>
                </div>
                <div className="flex justify-end items-center flex-wrap gap-3">


                    <Button asChild className="px-4 bg-red-600 hover:bg-red-700 text-primary-foreground">
                        <Link href="/store/checkout/payment-method">
                            روش پرداخت
                            <MoveRight className="text-base"/>
                        </Link>
                    </Button>

                    <Button asChild variant="outline" className="p-5">
                        <Link href="/store/checkout/order-summary">
                            <MoveLeft className="text-base"/>
                            خلاصه سفارش
                        </Link>
                    </Button>
                </div>
            </div>

            <div className="lg:col-span-1">
                <div className="space-y-5">
                    <Order/>
                </div>
            </div>
        </div>
    );
}
