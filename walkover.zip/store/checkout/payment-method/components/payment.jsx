
'use client';

import { Fragment, useEffect, useState } from 'react';
import Link from 'next/link';
import { zodResolver } from '@hookform/resolvers/zod';
import { RiCheckboxCircleFill } from '@remixicon/react';
import { useForm } from 'react-hook-form';
import { toast } from 'sonner';
import { toAbsoluteUrl } from '@/lib/helpers';
import { Alert, AlertIcon, AlertTitle } from '@/store/components/ui/alert';
import { Badge } from '@/store/components/ui/badge';
import { Button } from '@/store/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/store/components/ui/card';
import {
  Dialog,
  DialogBody,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/store/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/store/components/ui/form';
import { Input } from '@/store/components/ui/input';
import { paymentMethodSchema } from './forms';

export function Payment() {
  // اطلاعات نمونه روش‌های پرداخت
  const [items, setItems] = useState([
    {
      brandLogo: 'visa.svg',
      title: 'ویزای جیرون',
      subTitle: 'Jeroen van Dijk',
      description: (
        <span className="text-xs font-normal text-mono">
          پایان شماره کارت ۳۶۰۴ - انقضا: 12/2026
        </span>
      ),
      badge: true,
      cardNumber: '4111 1111 1111 3604',
      expiry: '12/2026',
      name: 'Jeroen van Dijk',
      cvc: '123',
      billingAddress: 'Keizersgracht 123, Amsterdam',
    },
    {
      brandLogo: 'ideal.svg',
      title: 'آی‌دیل سوفی',
      subTitle: 'Sophie de Vries',
      description: (
        <span className="text-xs font-normal text-mono">
          پرداخت از طریق iDeal با بانک ABN AMRO
        </span>
      ),
      name: 'Sophie de Vries',
      billingAddress: 'Herengracht 456, Amsterdam',
    },
    {
      brandLogo: 'paypal.svg',
      title: 'پی‌پال اِما',
      subTitle: 'Emma van den Berg',
      description: (
        <Link
          href="#"
          className="hover:text-primary text-sm font-medium text-secondary-foreground"
        >
          emma@reui.io
        </Link>
      ),
      email: 'emma@reui.io',
      name: 'Emma van den Berg',
    },
    {
      brandLogo: 'american-express.svg',
      title: 'آمریکن اکسپرس باب',
      subTitle: 'Bob van den Berg',
      description: (
        <Link
          href="#"
          className="hover:text-primary text-sm font-medium text-secondary-foreground"
        >
          bob@reui.io
        </Link>
      ),
      email: 'bob@reui.io',
      name: 'Bob van den Berg',
    },
  ]);

  // وضعیت پنجره‌های ویرایش و حذف
  const [editOpen, setEditOpen] = useState(null);
  const [removeOpen, setRemoveOpen] = useState(null);

  // فرم ویرایش روش پرداخت
  const form = useForm({
    resolver: zodResolver(paymentMethodSchema),
    defaultValues: {
      name: '',
      cardNumber: '',
      expiry: '',
      cvc: '',
      email: '',
      billingAddress: '',
    },
    mode: 'onChange',
  });

  useEffect(() => {
    if (editOpen !== null) {
      const item = items[editOpen];

      form.reset({
        name: item?.name || '',
        cardNumber: item?.cardNumber || '',
        expiry: item?.expiry || '',
        cvc: item?.cvc || '',
        email: item?.email || '',
        billingAddress: item?.billingAddress || '',
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editOpen]);

  // باز کردن پنجره ویرایش
  const handleEditOpen = (item, idx) => {
    setEditOpen(idx);
  };

  // ثبت تغییرات روش پرداخت
  const handleEditSubmit = async (data) => {
    if (editOpen === null) return;

    setItems((prev) =>
      prev.map((item, i) => (i === editOpen ? { ...item, ...data } : item)),
    );

    setEditOpen(null);
  };

  // حذف روش پرداخت
  const handleRemove = (idx) => {
    setItems((prev) => prev.filter((_, i) => i !== idx));
    setRemoveOpen(null);
  };

  // نمایش هر روش پرداخت
  const renderItem = (item, index) => (
    <Card key={index}>
      <CardHeader className="px-5">
        <CardTitle>{item.title}</CardTitle>

        {item.badge && (
          <Badge variant="success" appearance="light">
            روش پرداخت پیش‌فرض
          </Badge>
        )}
      </CardHeader>

      <CardContent className="px-5 space-y-5">
        <div className="flex items-center gap-3">
          <img
            src={toAbsoluteUrl(`/media/brand-logos/${item.brandLogo}`)}
            className="size-12"
            alt="لوگوی روش پرداخت"
          />

          <div className="flex flex-col gap-0.5">
            <span className="text-xs font-semibold text-mono">
              {item.subTitle}
            </span>
            {item.description}
          </div>
        </div>

        <div className="flex justify-between items-center min-h-8.5">
          <div className="flex items-center gap-5">
            {/* پنجره ویرایش */}
            <Dialog
              open={editOpen === index}
              onOpenChange={(open) =>
                open ? handleEditOpen(item, index) : setEditOpen(null)
              }
            >
              <DialogTrigger asChild>
                <Button mode="link" underlined="dashed">
                  ویرایش
                </Button>
              </DialogTrigger>

              <DialogContent>
                <DialogHeader>
                  <DialogTitle>ویرایش روش پرداخت</DialogTitle>
                  <DialogDescription>
                    اطلاعات روش پرداخت خود را در فرم زیر ویرایش کنید.
                    تکمیل تمام فیلدها الزامی است.
                  </DialogDescription>
                </DialogHeader>

                <DialogBody>
                  <Form {...form}>
                    <form
                      onSubmit={form.handleSubmit(handleEditSubmit)}
                      className="block w-full space-y-5"
                    >
                      {item.cardNumber !== undefined && (
                        <FormField
                          control={form.control}
                          name="cardNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>شماره کارت</FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  id="cardNumber"
                                  maxLength={19}
                                  pattern="[0-9 ]{13,19}"
                                  required
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}

                      {item.expiry !== undefined && (
                        <div className="flex gap-2">
                          <FormField
                            control={form.control}
                            name="expiry"
                            render={({ field }) => (
                              <FormItem className="flex-1">
                                <FormLabel>تاریخ انقضا</FormLabel>
                                <FormControl>
                                  <Input
                                    {...field}
                                    id="expiry"
                                    placeholder="MM/YYYY"
                                    required
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={form.control}
                            name="cvc"
                            render={({ field }) => (
                              <FormItem className="flex-1">
                                <FormLabel>کد امنیتی (CVC)</FormLabel>
                                <FormControl>
                                  <Input
                                    {...field}
                                    id="cvc"
                                    maxLength={4}
                                    required
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      )}

                      {item.email !== undefined && (
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>ایمیل</FormLabel>
                              <FormControl>
                                <Input
                                  {...field}
                                  id="email"
                                  type="email"
                                  required
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}

                      <FormField
                        control={form.control}
                        name="billingAddress"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>نشانی صورتحساب</FormLabel>
                            <FormControl>
                              <Input {...field} id="billingAddress" required />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <DialogFooter>
                        <Button type="submit" variant="primary">
                          ذخیره تغییرات
                        </Button>

                        <DialogClose asChild>
                          <Button type="button" variant="outline">
                            انصراف
                          </Button>
                        </DialogClose>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogBody>
              </DialogContent>
            </Dialog>

            {/* پنجره حذف */}
            <Dialog
              open={removeOpen === index}
              onOpenChange={(open) =>
                open ? setRemoveOpen(index) : setRemoveOpen(null)
              }
            >
              <DialogTrigger asChild>
                <Button mode="link" underlined="dashed">
                  حذف
                </Button>
              </DialogTrigger>

              <DialogContent>
                <DialogHeader>
                  <DialogTitle>حذف روش پرداخت</DialogTitle>
                </DialogHeader>

                <DialogBody className="text-sm">
                  آیا از حذف این روش پرداخت اطمینان دارید؟
                </DialogBody>

                <DialogFooter>
                  <Button
                    variant="destructive"
                    onClick={() => handleRemove(index)}
                  >
                    بله، حذف شود
                  </Button>

                  <DialogClose asChild>
                    <Button variant="outline">انصراف</Button>
                  </DialogClose>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          {item.badge !== true && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => handleSelect(index)}
            >
              انتخاب به‌عنوان پیش‌فرض
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );

  // انتخاب روش پرداخت پیش‌فرض
  const handleSelect = (idx) => {
    setItems((prev) =>
      prev.map((item, i) => ({
        ...item,
        badge: i === idx,
      })),
    );

    toast.custom(
      (t) => (
        <Alert variant="mono" icon="success" onClose={() => toast.dismiss(t)}>
          <AlertIcon>
            <RiCheckboxCircleFill />
          </AlertIcon>
          <AlertTitle>روش پرداخت پیش‌فرض با موفقیت تغییر کرد</AlertTitle>
        </Alert>
      ),
      {
        duration: 5000,
      },
    );
  };

  return (
    <Fragment>
      {items.map((item, index) => {
        return renderItem(item, index);
      })}
    </Fragment>
  );
}
