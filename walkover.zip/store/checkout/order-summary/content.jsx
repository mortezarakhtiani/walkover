'use client';

import Link from 'next/link';
import {MoveRight} from 'lucide-react';
import {Button} from '@/store/components/ui/button';
import {Order} from '@/store/checkout/order-summary/components/order';
import {Card4} from '@/store/components/common/card4';

export function OrderSummaryContent() {
    return (
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-5 lg:gap-9 mb-5 lg:mb-10">
            <div className="col-span-2 space-y-5">
                <div className="grid sm:grid-cols-1 gap-5">
                    <Card4 limit={4}/>
                </div>
                <div className="flex justify-end items-center flex-wrap gap-3">

                    <Button asChild className="px-4 bg-red-600 hover:bg-red-700 text-primary-foreground">
                        <Link href="/store/checkout/shipping-info">
                            اطلاعات ارسال
                            <MoveRight className="text-base"/>
                        </Link>
                    </Button>

                    <Button variant="outline" className="p-5">منصرف شدم</Button>
                </div>
            </div>

            <div className="col-span-1">
                <div className="space-y-5">
                    <Order/>
                </div>
            </div>
        </div>
    );
}
