'use client';

import {Fragment} from 'react';
import Link from 'next/link';
import {
    Toolbar,
    ToolbarActions,
    ToolbarDescription,
    ToolbarHeading,
    ToolbarPageTitle,
} from '@/partials/common/toolbar';
import {MapPinned} from 'lucide-react';
import {Button} from '@/store/components/ui/button';
import {Container} from '@/store/components/common/container';
import {ShippingInfoContent} from '@/store/checkout/shipping-info/content';
import {Steps} from '@/store/checkout/steps';

export default function ShippingInfoPage() {
    return (
        <Fragment>
            <Steps currentStep={1}/>
            <Container>
                <Toolbar>
                    <ToolbarHeading>
                        <ToolbarPageTitle/>
                        <ToolbarDescription>
                            نشانی تحویل خود را وارد و تأیید کنید
                        </ToolbarDescription>
                    </ToolbarHeading>
                    <ToolbarActions>
                        <Button variant="outline">
                            <MapPinned/>
                            <Link href="#">افزودن نشانی</Link>
                        </Button>
                    </ToolbarActions>
                </Toolbar>
            </Container>
            <Container className="pb-10">
                <ShippingInfoContent/>
            </Container>
        </Fragment>
    );
}
